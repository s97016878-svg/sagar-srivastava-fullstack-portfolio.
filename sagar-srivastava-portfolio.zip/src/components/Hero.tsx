import { motion } from 'motion/react';
import { Github, Linkedin, Instagram, Twitter, Download, ArrowRight } from 'lucide-react';
import { useEffect, useState } from 'react';

const SKILLS = [
  "React Developer",
  "MERN Stack Developer",
  "Frontend Designer",
  "Backend Developer"
];

export function Hero() {
  const [skillIndex, setSkillIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setSkillIndex((prev) => (prev + 1) % SKILLS.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-24 pb-12 overflow-hidden">
      
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 lg:gap-8 items-center w-full z-10">
        
        {/* Text Content */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col gap-6"
        >
          <div className="inline-flex items-center gap-3">
            <span className="w-12 h-[1px] bg-red-500"></span>
            <span className="text-red-500 font-mono tracking-wider uppercase text-sm">Welcome to my world</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight leading-tight">
            Hi, I'm <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-red-800 drop-shadow-[0_0_15px_rgba(255,0,0,0.5)]">
              Sagar Srivastava
            </span>
          </h1>

          <div className="h-12 flex items-center">
            <motion.p
               key={skillIndex}
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               exit={{ opacity: 0, y: -10 }}
               transition={{ duration: 0.5 }}
               className="text-2xl md:text-3xl font-light text-gray-300 border-l-4 border-red-500 pl-4"
            >
              A <b className="font-semibold text-white">{SKILLS[skillIndex]}</b>
            </motion.p>
          </div>

          <p className="text-gray-400 max-w-lg leading-relaxed text-lg">
            I craft cinematic, high-performance web applications with modern technologies. 
            Blending solid backend functionality with stunning, intuitive user interfaces.
          </p>

          <div className="flex flex-wrap items-center gap-4 mt-4">
            <a href="#contact" className="px-8 py-3 bg-red-600 hover:bg-red-700 text-white font-medium rounded transition-all shadow-[0_0_20px_rgba(255,0,0,0.4)] hover:shadow-[0_0_30px_rgba(255,0,0,0.6)] flex items-center gap-2">
              Hire Me <ArrowRight className="w-4 h-4" />
            </a>
            <a href="#projects" className="px-8 py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-medium rounded transition-all backdrop-blur-sm">
              View Projects
            </a>
            <button className="px-8 py-3 text-red-500 hover:text-white border border-red-500/50 hover:bg-red-500/10 font-medium rounded transition-all flex items-center gap-2">
              <Download className="w-4 h-4" /> Resume
            </button>
          </div>

          <div className="flex items-center gap-5 mt-8">
            <p className="text-sm font-mono text-gray-500 uppercase tracking-widest mr-4">Find Me:</p>
            {[
              { icon: Github, link: "#" },
              { icon: Linkedin, link: "#" },
              { icon: Twitter, link: "#" },
              { icon: Instagram, link: "#" }
            ].map((Social, idx) => (
              <a key={idx} href={Social.link} className="w-10 h-10 rounded bg-white/5 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-white/10 hover:shadow-[0_0_15px_rgba(255,0,0,0.3)] transition-all border border-white/5">
                <Social.icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </motion.div>

        {/* Profile Image */}
        <motion.div
           initial={{ opacity: 0, scale: 0.8 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1, ease: 'easeOut' }}
           className="relative flex justify-center lg:justify-end"
        >
          {/* Animated red rings */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] md:w-[450px] h-[350px] md:h-[450px] rounded-full border border-red-500/30 animate-[spin_10s_linear_infinite]" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] md:w-[500px] h-[400px] md:h-[500px] rounded-full border border-red-500/10 animate-[spin_15s_linear_infinite_reverse]" />
          
          <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-2xl overflow-hidden border border-red-500/30 shadow-[0_0_50px_rgba(255,0,0,0.2)] group bg-zinc-900 filter grayscale hover:grayscale-0 transition-all duration-700">
            {/* Soft inner glow */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
            
            {/* Generate Image based upon persona placeholder */}
            <img 
              src="https://images.unsplash.com/photo-1555952517-2e8e729e0b44?auto=format&fit=crop&q=80&w=1000" 
              alt="Sagar Srivastava"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700" 
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
