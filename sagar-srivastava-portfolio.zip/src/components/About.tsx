import { motion } from 'motion/react';
import { Code2, MonitorPlay, Zap } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-24 relative z-10 w-full overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 md:text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            About <span className="text-red-500">Me</span>
          </h2>
          <div className="w-24 h-1 bg-red-500/50 md:mx-auto">
            <div className="w-12 h-full bg-red-500 animate-pulse" />
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute inset-0 bg-red-500/10 blur-[80px] rounded-full point-events-none" />
            <div className="relative p-8 rounded-2xl bg-white/5 border border-white/5 backdrop-blur-sm hover:border-red-500/30 transition-colors group">
               <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-100 transition-opacity">
                 <Zap className="w-24 h-24 text-red-500" />
               </div>
               
               <h3 className="text-2xl font-bold text-white mb-6">Professional Introduction</h3>
               <p className="text-gray-400 mb-6 text-lg leading-relaxed">
                 I am a <span className="text-white font-medium">BCA Final Year Student</span> deeply passionate about modern web technologies. I specialize in building robust, interactive, and visually stunning web applications from the ground up.
               </p>
               <p className="text-gray-400 text-lg leading-relaxed">
                 My journey in coding started with a curiosity for how things work on the internet, 
                 which quickly transformed into a passion for software craftsmanship. I enjoy bridging 
                 the gap between complex backend architectures and beautiful frontend interfaces.
               </p>
            </div>
          </motion.div>

          <div className="flex flex-col gap-6">
            {[
               { icon: Code2, title: "Clean Code", desc: "Writing maintainable, scalable, and efficient architecture." },
               { icon: MonitorPlay, title: "Modern Design", desc: "Creating pixel-perfect, responsive UI with glassmorphism and animations." },
               { icon: Zap, title: "Performance First", desc: "Optimizing for speed, accessibility, and SEO best practices." }
            ].map((feature, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
                className="flex items-start gap-4 p-6 rounded-xl bg-gradient-to-r from-zinc-900 to-black border border-white/5 hover:border-red-500/30 shadow-lg group hover:shadow-[0_0_15px_rgba(255,0,0,0.1)] transition-all"
              >
                <div className="w-12 h-12 shrink-0 rounded bg-red-500/10 flex items-center justify-center text-red-500 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-white mb-2">{feature.title}</h4>
                  <p className="text-gray-400">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}
