export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black py-8 relative z-10">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} Sagar Srivastava. All rights reserved.
        </p>
        <div className="flex items-center gap-6">
          <a href="#" className="text-gray-500 hover:text-red-500 text-sm transition-colors">Privacy Policy</a>
          <a href="#" className="text-gray-500 hover:text-red-500 text-sm transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
}
