import { motion } from 'motion/react';
import { ExternalLink, Github, Monitor } from 'lucide-react';

const PROJECTS_DATA = [
  {
    title: "E-Commerce Website",
    desc: "A full-stack e-commerce platform with secure payment gateway, admin dashboard, and real-time inventory management.",
    tech: ["React.js", "Node.js", "MongoDB", "Tailwind CSS"],
    image: "https://images.unsplash.com/photo-1557821552-17105153ce97?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Portfolio Website",
    desc: "A cinematic, highly animated developer portfolio with dark theme, glassmorphism UI, and 3D effects.",
    tech: ["Next.js", "Framer Motion", "Tailwind CSS", "GSAP"],
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Task Management System",
    desc: "A collaborative project management tool featuring drag-and-drop kanban boards, real-time chat, and role-based access.",
    tech: ["React.js", "Express", "Socket.io", "MySQL"],
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    title: "Blog Application",
    desc: "A modern content management system with markdown support, SEO optimization, and user authentication.",
    tech: ["MERN Stack", "Redux Toolkit", "JWT", "Cloudinary"],
    image: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "#"
  }
];

export function Projects() {
  return (
    <section id="projects" className="py-24 relative z-10 w-full overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 md:text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Featured <span className="text-red-500">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-red-500/50 md:mx-auto">
            <div className="w-12 h-full bg-red-500 animate-pulse" />
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-10">
          {PROJECTS_DATA.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group relative rounded-2xl overflow-hidden bg-zinc-900 border border-white/5 hover:border-red-500/50 transition-all duration-500 shadow-xl"
            >
              {/* Image Container */}
              <div className="relative h-64 overflow-hidden">
                <div className="absolute inset-0 bg-black/50 group-hover:bg-transparent transition-colors duration-500 z-10" />
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter grayscale group-hover:grayscale-0"
                />
                
                {/* Floating Action Buttons */}
                <div className="absolute top-4 right-4 z-20 flex gap-3 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                  <a href={project.liveUrl} className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center text-white hover:bg-red-500 shadow-[0_0_15px_rgba(255,0,0,0.5)]">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <a href={project.githubUrl} className="w-10 h-10 rounded-full bg-black/80 backdrop-blur flex items-center justify-center text-white hover:text-red-500 border border-white/10 hover:border-red-500/50">
                    <Github className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {/* Content Container */}
              <div className="p-8 relative">
                {/* Neon Glow overlay on hover */}
                <div className="absolute inset-0 bg-red-500/0 group-hover:bg-red-500/5 transition-colors duration-500 pointer-events-none" />
                
                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-red-400 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 mb-6 leading-relaxed line-clamp-2">
                  {project.desc}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech) => (
                    <span 
                      key={tech} 
                      className="px-3 py-1 text-xs font-mono text-red-400 bg-red-500/10 border border-red-500/20 rounded uppercase tracking-wider"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Bottom Glowing Line */}
              <div className="absolute bottom-0 left-0 w-0 h-1 bg-gradient-to-r from-red-600 to-red-400 group-hover:w-full transition-all duration-700 ease-out shadow-[0_0_10px_rgba(255,0,0,0.8)]" />
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
            <a href="#" className="inline-flex items-center gap-2 px-8 py-3 text-red-500 hover:text-white border border-red-500/50 hover:bg-red-500/20 font-medium rounded transition-all shadow-[0_0_15px_rgba(255,0,0,0)] hover:shadow-[0_0_20px_rgba(255,0,0,0.3)] uppercase tracking-widest text-sm">
              <Monitor className="w-4 h-4" /> View All Projects
            </a>
        </div>
      </div>
    </section>
  );
}
