import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

const TESTIMONIALS = [
  {
    name: "Alex Johnson",
    role: "CEO at TechStartup",
    content: "Sagar is an exceptional developer. He transformed our vague ideas into a stunning, fully-functional web application. His attention to detail in the UI is unmatched.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
  {
    name: "Sarah Williams",
    role: "Design Lead",
    content: "Working with Sagar was a breeze. He perfectly bridged the gap between my designs and the final codebase. The fluid animations he added brought the whole project to life.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
  {
    name: "Michael Chen",
    role: "Product Manager",
    content: "Delivered on time, clean code, and incredibly responsive to feedback. Sagar's full-stack knowledge meant he could handle database architecture just as well as frontend state.",
    image: "https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  }
];

export function Testimonials() {
  return (
    <section className="py-24 relative z-10 w-full overflow-hidden bg-zinc-950/50">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 md:text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Client <span className="text-red-500">Testimonials</span>
          </h2>
          <div className="w-24 h-1 bg-red-500/50 md:mx-auto">
            <div className="w-12 h-full bg-red-500 animate-pulse" />
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="relative p-8 rounded-2xl bg-black/40 border border-white/5 backdrop-blur-md hover:border-red-500/30 transition-all duration-300 group"
            >
              <Quote className="absolute top-6 right-6 w-12 h-12 text-white/5 group-hover:text-red-500/10 transition-colors duration-300" />
              
              <div className="flex items-center gap-4 mb-6">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-14 h-14 rounded-full border-2 border-red-500/20 group-hover:border-red-500 transition-colors"
                />
                <div>
                  <h4 className="text-white font-semibold">{testimonial.name}</h4>
                  <p className="text-gray-500 text-sm">{testimonial.role}</p>
                </div>
              </div>
              
              <p className="text-gray-400 leading-relaxed italic">
                "{testimonial.content}"
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
