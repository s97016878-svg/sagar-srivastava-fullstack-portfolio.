import { motion } from 'motion/react';
import { Layout, Server, Database, Smartphone, Webhook, Palette } from 'lucide-react';

const SERVICES_DATA = [
  {
    title: "Frontend Development",
    desc: "Building pixel-perfect, highly animated, and responsive user interfaces using React, Next.js, and Tailwind CSS.",
    icon: Layout
  },
  {
    title: "Backend Development",
    desc: "Creating robust and secure server-side logic, real-time architectures, and scalable microservices via Node.js.",
    icon: Server
  },
  {
    title: "Full Stack Web Apps",
    desc: "End-to-end web application development. From database modeling to beautiful client-side experiences.",
    icon: Database
  },
  {
    title: "Responsive UI Design",
    desc: "Ensuring applications look immaculate on any device, from massive desktop monitors down to mobile screens.",
    icon: Smartphone
  },
  {
    title: "API Integration",
    desc: "Seamlessly connecting third-party services, RESTful APIs, and GraphQL endpoints to enrich application functionality.",
    icon: Webhook
  },
  {
    title: "Creative Interactions",
    desc: "Implementing customized GSAP and Framer Motion animations for that cinematic, premium feel.",
    icon: Palette
  }
];

export function Services() {
  return (
    <section className="py-24 relative z-10 w-full overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 md:text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            My <span className="text-red-500">Services</span>
          </h2>
          <div className="w-24 h-1 bg-red-500/50 md:mx-auto">
            <div className="w-12 h-full bg-red-500 animate-pulse" />
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES_DATA.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-8 rounded-2xl bg-gradient-to-br from-zinc-900 to-black border border-white/5 hover:border-red-500/40 transition-all duration-300 group shadow-lg hover:shadow-[0_0_30px_rgba(255,0,0,0.1)] relative overflow-hidden"
            >
              {/* Background Glow */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 rounded-full blur-[50px] group-hover:bg-red-500/20 transition-colors duration-500" />
              
              <div className="w-14 h-14 rounded-xl bg-black border border-white/10 flex items-center justify-center text-red-500 mb-6 group-hover:scale-110 group-hover:bg-red-500/10 group-hover:border-red-500/30 transition-all duration-300 relative z-10">
                <service.icon className="w-7 h-7" />
              </div>
              
              <h3 className="text-xl font-bold text-white mb-4 relative z-10">{service.title}</h3>
              <p className="text-gray-400 leading-relaxed text-sm relative z-10">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
