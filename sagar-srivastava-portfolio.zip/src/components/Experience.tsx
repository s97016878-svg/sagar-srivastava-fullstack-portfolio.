import { motion } from 'motion/react';
import { Briefcase, GraduationCap } from 'lucide-react';

const EXPERIENCE_DATA = [
  {
    title: "Full Stack Developer Intern",
    company: "Tech Solutions Inc.",
    date: "2024 - Present",
    desc: "Worked on developing MERN stack applications. Improved core application performance by 20% and implemented responsive UI designs.",
    type: "work"
  },
  {
    title: "Bachelor of Computer Applications (BCA)",
    company: "University of Technology",
    date: "2024 - Present (Final Year)",
    desc: "Specializing in Software Development, Data Structures, and Web Technologies. Maintained a CGPA of 8.5/10.",
    type: "edu"
  },
  {
    title: "Web Development Intern",
    company: "Creative Digital Agency",
    date: "Summer 2025",
    desc: "Created highly interactive landing pages using React and Tailwind CSS. Collaborated closely with the design team to implement glassmorphism UIs.",
    type: "work"
  }
];

export function Experience() {
  return (
    <section id="experience" className="py-24 relative z-10 w-full bg-zinc-950/50">
      <div className="max-w-4xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Experience & <span className="text-red-500">Education</span>
          </h2>
          <div className="w-24 h-1 bg-red-500/50 mx-auto">
            <div className="w-12 h-full bg-red-500 animate-pulse" />
          </div>
        </motion.div>

        <div className="relative border-l-2 border-red-500/20 ml-4 md:ml-0 md:border-l-0">
            {/* Desktop Center Line */}
            <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-red-500/20 -translate-x-1/2" />

            <div className="flex flex-col gap-12">
            {EXPERIENCE_DATA.map((item, index) => (
                <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.2 }}
                    className={`relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group mx-4 md:mx-0`}
                >
                    {/* Timeline Icon */}
                    <div className="absolute -left-10 md:left-1/2 md:-translate-x-1/2 w-10 h-10 rounded-full border-4 border-black bg-zinc-900 flex items-center justify-center text-red-500 shadow-[0_0_15px_rgba(255,0,0,0.5)] z-10 group-hover:scale-110 group-hover:bg-red-500 group-hover:text-white transition-all">
                        {item.type === 'work' ? <Briefcase className="w-4 h-4" /> : <GraduationCap className="w-4 h-4" />}
                    </div>

                    {/* Content Card */}
                    <div className="w-full md:w-[calc(50%-3rem)] p-6 rounded-2xl bg-black/40 border border-white/5 backdrop-blur-md hover:border-red-500/30 transition-colors shadow-lg">
                        <div className="flex flex-col gap-1 mb-4">
                            <span className="text-red-500 font-mono text-sm uppercase tracking-wider">{item.date}</span>
                            <h3 className="text-xl font-bold text-white">{item.title}</h3>
                            <span className="text-gray-400 font-medium">{item.company}</span>
                        </div>
                        <p className="text-gray-400 text-sm leading-relaxed">
                            {item.desc}
                        </p>
                    </div>
                </motion.div>
            ))}
            </div>
        </div>
      </div>
    </section>
  );
}
