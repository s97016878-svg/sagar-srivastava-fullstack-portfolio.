import { motion } from 'motion/react';

const SKILLS_DATA = [
  { name: "React.js", level: 95 },
  { name: "Node.js", level: 85 },
  { name: "Express.js", level: 80 },
  { name: "MongoDB", level: 85 },
  { name: "Tailwind CSS", level: 95 },
  { name: "JavaScript", level: 90 },
  { name: "HTML & CSS", level: 95 },
  { name: "MySQL", level: 75 },
  { name: "Git & GitHub", level: 85 },
];

export function Skills() {
  return (
    <section id="skills" className="py-24 relative z-10 w-full bg-zinc-950/50">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 md:text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Technical <span className="text-red-500">Skills</span>
          </h2>
          <div className="w-24 h-1 bg-red-500/50 md:mx-auto">
            <div className="w-12 h-full bg-red-500 animate-pulse" />
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SKILLS_DATA.map((skill, index) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-6 rounded-2xl bg-black/40 border border-white/5 backdrop-blur-md hover:border-red-500/40 hover:shadow-[0_0_20px_rgba(255,0,0,0.15)] group transition-all"
            >
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-medium text-white tracking-wide">{skill.name}</span>
                <span className="text-red-500 font-mono text-sm">{skill.level}%</span>
              </div>
              <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.5, ease: "easeOut", delay: index * 0.1 }}
                  className="h-full bg-gradient-to-r from-red-600 to-red-400 rounded-full relative"
                >
                  <div className="absolute top-0 right-0 bottom-0 w-8 bg-white/20 blur-sm translate-x-4 mix-blend-overlay" />
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
