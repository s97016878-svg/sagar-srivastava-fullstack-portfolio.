/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { About } from './components/About';
import { Contact } from './components/Contact';
import { CustomCursor } from './components/CustomCursor';
import { Experience } from './components/Experience';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { Navbar } from './components/Navbar';
import { Particles } from './components/Particles';
import { Projects } from './components/Projects';
import { Services } from './components/Services';
import { Skills } from './components/Skills';
import { Testimonials } from './components/Testimonials';

export default function App() {
  return (
    <div className="bg-black min-h-screen text-white font-sans selection:bg-red-500/30 selection:text-red-200">
      <CustomCursor />
      <Particles />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Services />
        <Projects />
        <Experience />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
